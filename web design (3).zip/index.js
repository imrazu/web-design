
setInterval(function() {
    
    if (document.getElementsByClassName("slider-items")[0].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[1].classList.add("active");
    document.getElementsByClassName("slider-items")[0].classList.remove("active");
    
}else if (document.getElementsByClassName("slider-items")[1].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[2].classList.add("active");
    document.getElementsByClassName("slider-items")[1].classList.remove("active");
    
}else if (document.getElementsByClassName("slider-items")[2].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[0].classList.add("active");
    document.getElementsByClassName("slider-items")[2].classList.remove("active");
}

},4000);


document.querySelector('#btn').addEventListener('click',function(){

    
if (document.getElementsByClassName("slider-items")[0].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[1].classList.add("active");
    document.getElementsByClassName("slider-items")[0].classList.remove("active");
    
}else if (document.getElementsByClassName("slider-items")[1].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[2].classList.add("active");
    document.getElementsByClassName("slider-items")[1].classList.remove("active");
    
}else if (document.getElementsByClassName("slider-items")[2].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[0].classList.add("active");
    document.getElementsByClassName("slider-items")[2].classList.remove("active");
}


}


);

document.querySelector('#btn2').addEventListener('click',function(){

    
if (document.getElementsByClassName("slider-items")[0].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[2].classList.add("active");
    document.getElementsByClassName("slider-items")[0].classList.remove("active");
    
}else if (document.getElementsByClassName("slider-items")[2].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[1].classList.add("active");
    document.getElementsByClassName("slider-items")[2].classList.remove("active");
    
}else if (document.getElementsByClassName("slider-items")[1].classList.contains("active")) {
    
    document.getElementsByClassName("slider-items")[0].classList.add("active");
    document.getElementsByClassName("slider-items")[1].classList.remove("active");
}

} );

//////home button

document.getElementById('homebtn').addEventListener('click', function (){
  
  window.scrollBy(0,-3200);
  
} )






